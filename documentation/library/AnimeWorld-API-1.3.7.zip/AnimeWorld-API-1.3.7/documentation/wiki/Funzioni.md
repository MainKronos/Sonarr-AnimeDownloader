## def find
`find(animeName)`

**Parameters**
> **animeName** ( [str](https://docs.python.org/3/library/stdtypes.html#str) ) – Nome dell'anime da ricercare nel sito AnimeWorld

**Raises**
> None

**Return**
> Un dizionario contentente per chiave il nome dell'anime e per valore il link della pagina di animeworld

**Return type**
> [dict](https://docs.python.org/3/library/stdtypes.html#dict)